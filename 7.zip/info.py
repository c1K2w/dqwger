import ctypes,platform,win32com.client,psutil,os,uuid,shutil
def get_cpu_info():
	class C(ctypes.Structure):_fields_=[('wProcessorArchitecture',ctypes.c_ushort),('wReserved',ctypes.c_ushort),('dwPageSize',ctypes.c_ulong),('lpMinimumApplicationAddress',ctypes.c_void_p),('lpMaximumApplicationAddress',ctypes.c_void_p),('dwActiveProcessorMask',ctypes.c_ulonglong),('dwNumberOfProcessors',ctypes.c_ulong),('dwProcessorType',ctypes.c_ulong),('dwAllocationGranularity',ctypes.c_ulong),('wProcessorLevel',ctypes.c_ushort),('wProcessorRevision',ctypes.c_ushort)]
	try:A=C();ctypes.windll.kernel32.GetSystemInfo(ctypes.byref(A));B={'Processor Architecture':A.wProcessorArchitecture,'Number of Processors':A.dwNumberOfProcessors,'Processor Type':A.dwProcessorType,'Processor Level':A.wProcessorLevel,'Processor Revision':A.wProcessorRevision}
	except Exception as D:B={'Error':f"Unable to retrieve CPU info: {D}"}
	return B
def get_gpu_info():
	A=''
	try:
		C=win32com.client.GetObject('winmgmts:');D=C.InstancesOf('Win32_VideoController')
		for B in D:A+=f"{B.Caption} (Driver Version: {B.DriverVersion})\n"
	except Exception as E:A=f"Error retrieving GPU info: {E}"
	return A
def get_memory_info():A={'Total Physical Memory':f"{psutil.virtual_memory().total/1024**3:.2f} GB",'Available Physical Memory':f"{psutil.virtual_memory().available/1024**3:.2f} GB",'Total Swap Memory':f"{psutil.swap_memory().total/1024**3:.2f} GB",'Free Swap Memory':f"{psutil.swap_memory().free/1024**3:.2f} GB"};return A
def get_disk_info():
	E='Mountpoint';D='Device';C=[];F=psutil.disk_partitions()
	for A in F:
		try:B=psutil.disk_usage(A.mountpoint);C.append({D:A.device,E:A.mountpoint,'File System Type':A.fstype,'Total Size':f"{B.total/1024**3:.2f} GB",'Used Space':f"{B.used/1024**3:.2f} GB",'Free Space':f"{B.free/1024**3:.2f} GB",'Percent Used':f"{B.percent}%"})
		except OSError as G:C.append({D:A.device,E:A.mountpoint,'Error':f"Unable to retrieve disk usage: {G}"})
	return C
def get_system_info():A={'System':platform.system(),'Node':platform.node(),'Release':platform.release(),'Version':platform.version(),'Machine':platform.machine(),'Processor':platform.processor(),'CPU Info':get_cpu_info(),'GPU Info':get_gpu_info(),'Memory Info':get_memory_info(),'Disk Info':get_disk_info()};return A
def save_info_to_file(info,filename):
	with open(filename,'w')as A:
		for(C,B)in info.items():
			if isinstance(B,list):
				A.write(f"{C}:\n")
				for F in B:
					for(D,E)in F.items():A.write(f"  {D}: {E}\n")
			elif isinstance(B,dict):
				A.write(f"{C}:\n")
				for(D,E)in B.items():A.write(f"  {D}: {E}\n")
			else:A.write(f"{C}: {B}\n")
def get_hwid():return str(uuid.getnode())
def search_folder_by_hwid(base_path,hwid):
	A=os.path.join(base_path,hwid)
	if os.path.exists(A)and os.path.isdir(A):return A
if __name__=='__main__':
	hwid=get_hwid();username=os.getlogin();base_search_path=f"C:\\Users\\{username}\\Documents";hwid_folder=search_folder_by_hwid(base_search_path,hwid)
	if hwid_folder:info=get_system_info();save_info_to_file(info,os.path.join(hwid_folder,'info.txt'))
	else:print(f"No folder found for HWID: {hwid} in {base_search_path}")