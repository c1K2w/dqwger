_A='screenshot.bmp'
import os,uuid,ctypes
from ctypes import wintypes
def get_hw_id():A=uuid.getnode();return A
def search_hwid_folder(hwid):
	B=os.path.expandvars('C:\\Users\\%username%\\Documents');C=str(hwid)
	for(D,E,F)in os.walk(B):
		for A in E:
			if C in A:return os.path.join(D,A)
class BITMAPINFOHEADER(ctypes.Structure):_fields_=[('biSize',wintypes.DWORD),('biWidth',wintypes.LONG),('biHeight',wintypes.LONG),('biPlanes',wintypes.WORD),('biBitCount',wintypes.WORD),('biCompression',wintypes.DWORD),('biSizeImage',wintypes.DWORD),('biXPelsPerMeter',wintypes.LONG),('biYPelsPerMeter',wintypes.LONG),('biClrUsed',wintypes.DWORD),('biClrImportant',wintypes.DWORD)]
class BITMAPINFO(ctypes.Structure):_fields_=[('bmiHeader',BITMAPINFOHEADER),('bmiColors',ctypes.c_uint*256)]
BI_RGB=0
SRCCOPY=13369376
DIB_RGB_COLORS=0
user32=ctypes.WinDLL('user32',use_last_error=True)
gdi32=ctypes.WinDLL('gdi32',use_last_error=True)
user32.GetDC.argtypes=[wintypes.HWND]
user32.GetDC.restype=wintypes.HDC
user32.ReleaseDC.argtypes=[wintypes.HWND,wintypes.HDC]
user32.ReleaseDC.restype=wintypes.INT
gdi32.CreateCompatibleDC.argtypes=[wintypes.HDC]
gdi32.CreateCompatibleDC.restype=wintypes.HDC
gdi32.CreateCompatibleBitmap.argtypes=[wintypes.HDC,wintypes.INT,wintypes.INT]
gdi32.CreateCompatibleBitmap.restype=wintypes.HBITMAP
gdi32.SelectObject.argtypes=[wintypes.HDC,wintypes.HGDIOBJ]
gdi32.SelectObject.restype=wintypes.HGDIOBJ
gdi32.BitBlt.argtypes=[wintypes.HDC,wintypes.INT,wintypes.INT,wintypes.INT,wintypes.INT,wintypes.HDC,wintypes.INT,wintypes.INT,wintypes.DWORD]
gdi32.BitBlt.restype=wintypes.BOOL
gdi32.GetDIBits.argtypes=[wintypes.HDC,wintypes.HBITMAP,wintypes.UINT,wintypes.UINT,wintypes.LPVOID,ctypes.POINTER(BITMAPINFO),wintypes.UINT]
gdi32.GetDIBits.restype=wintypes.UINT
gdi32.DeleteObject.argtypes=[wintypes.HGDIOBJ]
gdi32.DeleteObject.restype=wintypes.BOOL
gdi32.DeleteDC.argtypes=[wintypes.HDC]
gdi32.DeleteDC.restype=wintypes.BOOL
def get_screenshot(filename=_A):
	M=b'\x13\x0b\x00\x00';L=b'\x00\x00';J=b'\x00\x00\x00\x00';G='little';F=user32.GetDC(None);D=ctypes.windll.user32.GetSystemMetrics(0);C=ctypes.windll.user32.GetSystemMetrics(1);E=gdi32.CreateCompatibleDC(F);H=gdi32.CreateCompatibleBitmap(F,D,C);N=gdi32.SelectObject(E,H);gdi32.BitBlt(E,0,0,D,C,F,0,0,SRCCOPY);B=BITMAPINFO();B.bmiHeader.biSize=ctypes.sizeof(BITMAPINFOHEADER);B.bmiHeader.biWidth=D;B.bmiHeader.biHeight=C;B.bmiHeader.biPlanes=1;B.bmiHeader.biBitCount=24;B.bmiHeader.biCompression=BI_RGB;B.bmiHeader.biSizeImage=D*C*3;I=D*C*3;K=ctypes.create_string_buffer(I);gdi32.GetDIBits(E,H,0,C,K,ctypes.byref(B),DIB_RGB_COLORS)
	with open(filename,'wb')as A:A.write(b'BM');O=54+I;A.write(O.to_bytes(4,G));A.write(L);A.write(L);A.write(b'6\x00\x00\x00');A.write(b'(\x00\x00\x00');A.write(D.to_bytes(4,G));A.write(C.to_bytes(4,G));A.write(b'\x01\x00');A.write(b'\x18\x00');A.write(J);A.write(I.to_bytes(4,G));A.write(M);A.write(M);A.write(J);A.write(J);A.write(K)
	gdi32.SelectObject(E,N);gdi32.DeleteObject(H);gdi32.DeleteDC(E);user32.ReleaseDC(None,F)
if __name__=='__main__':
	hwid=get_hw_id();print(f"Hardware ID: {hwid}");hwid_folder=search_hwid_folder(hwid)
	if hwid_folder:print(f"HWID folder found: {hwid_folder}");screenshot_path=os.path.join(hwid_folder,_A);get_screenshot(screenshot_path);print(f"Screenshot saved to {screenshot_path}")
	else:print('HWID folder not found.')